export default function MilestoneCard({ milestone }) {
  const statusColor =
    milestone.status === "completed"
      ? "text-success"
      : milestone.status === "partial"
      ? "text-warning"
      : milestone.status === "failed"
      ? "text-danger"
      : "text-slate-300";

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-50">{milestone.title}</h3>
        <span className={`text-xs font-medium uppercase ${statusColor}`}>
          {milestone.status || "pending"}
        </span>
      </div>
      <ul className="text-xs text-slate-300 list-disc list-inside">
        {milestone.deliverables?.map((d) => (
          <li key={d}>{d}</li>
        ))}
      </ul>
      <div className="flex items-center justify-between text-xs text-slate-400 mt-2">
        <span>{milestone.deadline_days} days</span>
        <span>{milestone.payment_percentage}% of budget</span>
      </div>
    </div>
  );
}

