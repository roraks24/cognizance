import { useState } from "react";
import axios from "axios";

export default function ProjectForm({ onCreated }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [budget, setBudget] = useState("");
  const [deadline, setDeadline] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const token = window.localStorage.getItem("tf_token");
      const res = await axios.post(
        "http://localhost:8000/api/projects",
        {
          title,
          description,
          budget: parseFloat(budget),
          deadline: deadline || null
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      onCreated?.(res.data);
      setTitle("");
      setDescription("");
      setBudget("");
      setDeadline("");
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to create project");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4"
    >
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-1">
          Title
        </label>
        <input
          className="w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      <div>
        <label className="block text-xs font-medium text-slate-300 mb-1">
          Description
        </label>
        <textarea
          className="w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent min-h-[100px]"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Budget (USD)
          </label>
          <input
            type="number"
            min="0"
            step="0.01"
            className="w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Deadline
          </label>
          <input
            type="date"
            className="w-full rounded-lg border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
          />
        </div>
      </div>
      {error && (
        <p className="text-xs text-danger bg-danger/10 border border-danger/40 rounded px-2 py-1">
          {error}
        </p>
      )}
      <button
        type="submit"
        disabled={loading}
        className="inline-flex items-center justify-center rounded-lg bg-accent px-4 py-2 text-sm font-medium text-white hover:bg-accent/90 disabled:opacity-60"
      >
        {loading ? "Creating..." : "Create project with AI milestones"}
      </button>
    </form>
  );
}

