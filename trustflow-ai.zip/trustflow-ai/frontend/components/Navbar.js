import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="w-full border-b border-slate-800 bg-slate-900/80 backdrop-blur">
      <div className="max-w-6xl mx-auto flex items-center justify-between py-4 px-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="h-8 w-8 rounded-xl bg-accent/20 flex items-center justify-center text-accent font-bold">
            TF
          </span>
          <span className="font-semibold text-lg tracking-tight">TrustFlow AI</span>
        </Link>
        <div className="flex items-center gap-4 text-sm">
          <Link href="/dashboard" className="hover:text-accent transition-colors">
            Dashboard
          </Link>
          <Link href="/project" className="hover:text-accent transition-colors">
            New Project
          </Link>
        </div>
      </div>
    </nav>
  );
}

