/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#1F2937",
        accent: "#6366F1",
        success: "#22C55E",
        warning: "#F59E0B",
        danger: "#EF4444"
      }
    }
  },
  plugins: []
};

