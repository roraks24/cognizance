import Navbar from "@/components/Navbar";
import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <Navbar />
      <main className="flex-1">
        <div className="max-w-5xl mx-auto px-4 pt-16 pb-24 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl font-semibold tracking-tight text-slate-50">
              Autonomous escrow and{" "}
              <span className="text-accent">AI quality verification</span> for
              freelance projects.
            </h1>
            <p className="text-slate-300 text-sm md:text-base leading-relaxed">
              TrustFlow AI breaks your project into milestones, verifies
              deliverables with AI, and releases escrowed payments
              automatically—eliminating trust friction between employers and
              freelancers.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                href="/dashboard"
                className="inline-flex items-center rounded-lg bg-accent px-4 py-2 text-sm font-medium text-white hover:bg-accent/90"
              >
                Go to dashboard
              </Link>
              <Link
                href="/project"
                className="inline-flex items-center rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-100 hover:border-accent/70"
              >
                Create a project
              </Link>
            </div>
            <div className="grid grid-cols-3 gap-4 text-xs text-slate-300 pt-4">
              <div>
                <div className="text-lg font-semibold text-slate-50">AI QA</div>
                <p>LLM-powered code & deliverable verification.</p>
              </div>
              <div>
                <div className="text-lg font-semibold text-slate-50">Escrow</div>
                <p>Funds locked until objective milestone completion.</p>
              </div>
              <div>
                <div className="text-lg font-semibold text-slate-50">PFI</div>
                <p>Professional Fidelity Index reputation for freelancers.</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl shadow-accent/10 space-y-4">
            <h2 className="text-sm font-semibold text-slate-200 mb-2">
              Live milestone tracker
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">UI Design</span>
                <span className="text-success">Completed · 20%</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full w-1/5 bg-success" />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">API Integration</span>
                <span className="text-warning">In review · 40%</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full w-2/5 bg-warning" />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Final Delivery</span>
                <span className="text-slate-400">Pending · 40%</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full w-0 bg-accent" />
              </div>
            </div>
            <div className="mt-4 rounded-xl border border-slate-700/60 bg-slate-950/60 p-3 text-xs text-slate-300 space-y-1">
              <div className="flex justify-between">
                <span>Escrow balance</span>
                <span className="font-semibold text-slate-50">$8,000.00</span>
              </div>
              <div className="flex justify-between">
                <span>Released</span>
                <span className="text-success">$1,600.00</span>
              </div>
              <div className="flex justify-between">
                <span>Risk of failure</span>
                <span className="text-warning">24%</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

