import { useState } from "react";
import Navbar from "@/components/Navbar";
import ProjectForm from "@/components/ProjectForm";

export default function ProjectPage() {
  const [createdProject, setCreatedProject] = useState(null);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <Navbar />
      <main className="flex-1 max-w-3xl mx-auto w-full px-4 py-10 space-y-6">
        <header>
          <h1 className="text-2xl font-semibold text-slate-50">
            Create a new project
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Describe your work once. TrustFlow AI will analyze it, generate
            milestones, and prepare escrow workflows automatically.
          </p>
        </header>

        <ProjectForm onCreated={setCreatedProject} />

        {createdProject && (
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-xs text-slate-200 space-y-1">
            <h2 className="text-sm font-semibold text-slate-50">
              Project created
            </h2>
            <p className="text-slate-300">
              Title: <span className="font-medium">{createdProject.title}</span>
            </p>
            <p className="text-slate-300">
              Budget: <span className="font-medium">${createdProject.budget}</span>
            </p>
            <p className="text-slate-400">
              Navigate to the dashboard to see AI-generated milestones and
              escrow status.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

