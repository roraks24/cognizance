import { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "@/components/Navbar";
import MilestoneCard from "@/components/MilestoneCard";

export default function Dashboard() {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [role, setRole] = useState("employer");

  useEffect(() => {
    const storedRole = window.localStorage.getItem("tf_role");
    if (storedRole) setRole(storedRole);
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const token = window.localStorage.getItem("tf_token");
      const res = await axios.get("http://localhost:8000/api/projects", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProjects(res.data);
      if (res.data.length > 0) {
        setSelectedProject(res.data[0]);
        fetchMilestones(res.data[0].id);
      }
    } catch {
      // noop for brevity
    }
  };

  const fetchMilestones = async (projectId) => {
    try {
      const token = window.localStorage.getItem("tf_token");
      const res = await axios.get(
        `http://localhost:8000/api/milestones/${projectId}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setMilestones(res.data);
    } catch {
      setMilestones([]);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <Navbar />
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 space-y-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-slate-50">
              {role === "employer" ? "Employer dashboard" : "Freelancer dashboard"}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Track AI-generated milestones, escrow balances, and automated
              evaluations in one place.
            </p>
          </div>
        </header>

        <div className="grid md:grid-cols-[260px,1fr] gap-6">
          <aside className="space-y-3">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
              <h2 className="text-xs font-semibold text-slate-300 mb-2">
                Projects
              </h2>
              <div className="space-y-1">
                {projects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedProject(p);
                      fetchMilestones(p.id);
                    }}
                    className={`w-full text-left px-2 py-1.5 rounded-lg text-xs ${
                      selectedProject?.id === p.id
                        ? "bg-accent/20 text-accent"
                        : "text-slate-200 hover:bg-slate-800/80"
                    }`}
                  >
                    <div className="truncate font-medium">{p.title}</div>
                    <div className="text-[10px] text-slate-400">
                      Budget ${p.budget}
                    </div>
                  </button>
                ))}
                {projects.length === 0 && (
                  <p className="text-xs text-slate-500">
                    No projects yet. Create one from the New Project page.
                  </p>
                )}
              </div>
            </div>
          </aside>

          <section className="space-y-4">
            {selectedProject && (
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
                <h2 className="text-sm font-semibold text-slate-200">
                  {selectedProject.title}
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {selectedProject.description}
                </p>
                <div className="mt-3 flex items-center gap-4 text-xs text-slate-300">
                  <span>Budget: ${selectedProject.budget}</span>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-300">
                  Milestones
                </h3>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {milestones.map((m) => (
                  <MilestoneCard key={m.id} milestone={m} />
                ))}
                {milestones.length === 0 && (
                  <p className="text-xs text-slate-500">
                    No milestones yet or failed to load. Ensure the backend is
                    running and a project is selected.
                  </p>
                )}
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

