CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL,
    pfi_score DOUBLE PRECISION DEFAULT 500.0
);

CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    employer_id INTEGER NOT NULL REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    budget DOUBLE PRECISION NOT NULL,
    deadline TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS milestones (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    freelancer_id INTEGER NULL REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    deliverables TEXT NOT NULL,
    deadline_days INTEGER NOT NULL,
    payment_percentage DOUBLE PRECISION NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS wallets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE REFERENCES users(id),
    balance DOUBLE PRECISION NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    sender_id INTEGER NULL REFERENCES wallets(id),
    receiver_id INTEGER NULL REFERENCES wallets(id),
    amount DOUBLE PRECISION NOT NULL,
    type VARCHAR(32) NOT NULL,
    timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS escrow_accounts (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL UNIQUE REFERENCES projects(id),
    total_amount DOUBLE PRECISION NOT NULL,
    released_amount DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    status VARCHAR(32) NOT NULL DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS submissions (
    id SERIAL PRIMARY KEY,
    milestone_id INTEGER NOT NULL REFERENCES milestones(id),
    freelancer_id INTEGER NOT NULL REFERENCES users(id),
    github_repo_link VARCHAR(512) NOT NULL,
    files_summary TEXT NULL,
    score DOUBLE PRECISION NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'in_review',
    feedback TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

