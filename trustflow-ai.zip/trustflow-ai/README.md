## TrustFlow AI

TrustFlow AI is an AI-powered autonomous escrow and project management system that acts as a neutral intermediary between employers and freelancers. It automatically breaks projects into milestones, verifies work completion using AI, and releases payments from escrow based on milestone verification and quality scores.

### Problem Statement

Freelance work suffers from trust friction:

- **Employers** worry about paying for low‑quality or incomplete work.
- **Freelancers** worry about not getting paid after delivering value.

Traditional platforms rely on manual reviews and opaque reputation systems. Disputes are slow and subjective, and escrow is often locked behind human arbitration.

TrustFlow AI removes this friction by:

- Automating **requirement analysis** and **milestone generation** using LLMs.
- Locking funds in **on‑platform escrow** tied to objective milestones.
- Running **AI Quality Assurance (AQA)** on each submission (including GitHub analysis).
- Releasing funds automatically based on milestone scores.
- Maintaining a **Professional Fidelity Index (PFI)**, a transparent 300–850 reputation score for freelancers.

---

## Architecture Overview

**Frontend**

- Next.js
- TailwindCSS
- Pages:
  - `index.js` – marketing/landing page.
  - `dashboard.js` – employer/freelancer dashboard with milestone tracker.
  - `project.js` – project creation flow using AI-generated milestones.

**Backend**

- FastAPI (Python)
- JWT-based authentication
- SQLAlchemy ORM with PostgreSQL
- Service layer for:
  - User management and authentication
  - Project and milestone lifecycle
  - Escrow funding and payouts
  - Submission analysis and QA
  - PFI and risk scoring

**AI Layer**

- OpenAI API for:
  - Requirement analysis and milestone generation
  - Quality evaluation of submissions (AQA)
- GitHub API for:
  - Fetching repository trees and verifying required deliverables

**Database**

- PostgreSQL
- Schema managed via SQLAlchemy and `database/init.sql`

---

## Core Domain Concepts

- **User** – either an employer or a freelancer.
- **Project** – created by an employer, with a budget and deadline.
- **Milestone** – AI-generated units of work with deliverables, deadlines, and payment percentages.
- **EscrowAccount** – holds the total project budget until milestones are verified.
- **Submission** – a freelancer’s milestone delivery, including a GitHub repository link.
- **Transaction** – on‑platform movement of funds (deposit, escrow funding, payout, refund).
- **PFI (Professional Fidelity Index)** – 300–850 score indicating freelancer reliability.

---

## Tech Stack

- **Frontend**: Next.js, React, TailwindCSS, Axios
- **Backend**: FastAPI, SQLAlchemy, PostgreSQL
- **Auth**: JWT with `python-jose`
- **AI**: OpenAI ChatCompletion API
- **External**: GitHub API for repository inspections

Installable via:

- `requirements.txt` for Python dependencies.
- `frontend/package.json` for Node/Next.js dependencies.

---

## Installation & Setup

### 1. Clone and environment

```bash
git clone <your-repo-url> trustflow-ai
cd trustflow-ai
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Create a `.env` file (or set env vars) with:

```bash
DATABASE_URL=postgresql+psycopg2://trustflow:trustflow@localhost:5432/trustflow_ai
OPENAI_API_KEY=sk-...
GITHUB_TOKEN=ghp_...
```

### 2. Database

Create the database and run `database/init.sql`:

```bash
createdb trustflow_ai
psql trustflow_ai < database/init.sql
```

Alternatively, you can let SQLAlchemy create tables programmatically by importing `Base` and calling `Base.metadata.create_all(engine)`.

### 3. Backend (FastAPI)

From the project root:

```bash
cd backend
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`.

### 4. Frontend (Next.js)

```bash
cd frontend
npm install
npm run dev
```

The frontend will be available at `http://localhost:3000`.

---

## API Overview

Base path: `http://localhost:8000/api`

### Authentication & Users

- **POST `/signup`**
  - Create employer or freelancer user.
  - Body:
    - `name`: string
    - `email`: string
    - `password`: string
    - `role`: `"employer"` or `"freelancer"`
  - Response: `UserOut`

- **POST `/login`**
  - OAuth2 password flow to get JWT.
  - Form data:
    - `username`: email
    - `password`: password
  - Response:
    - `access_token`: JWT
    - `token_type`: `"bearer"`

- **GET `/me`**
  - Return current user profile (requires `Authorization: Bearer <token>`).

### Projects & Milestones

- **POST `/projects`**
  - Employer‑only endpoint to create a project.
  - Body:
    - `title`
    - `description`
    - `budget`
    - `deadline` (optional ISO timestamp)
  - Flow:
    1. Project persisted in DB.
    2. AI requirement analysis generates milestones.
    3. Milestones stored with titles, deliverables, deadlines, payment percentages.

- **GET `/projects`**
  - For employers: all owned projects.
  - For freelancers: projects associated via milestones.

- **GET `/milestones/{project_id}`**
  - List milestones for a project, with:
    - `title`
    - `deliverables[]`
    - `deadline_days`
    - `payment_percentage`
    - `status`

### Escrow

- **POST `/escrow/deposit/{project_id}`**
  - Employer deposits full project budget into escrow.
  - Requires employer wallet to have sufficient `balance`.
  - Creates an `EscrowAccount` and an `ESCROW_FUND` transaction.

- **GET `/escrow/{project_id}`**
  - Fetch escrow account for a project:
    - `total_amount`
    - `released_amount`
    - `status`

### Submissions & AI QA

- **POST `/submissions`**
  - Freelancer submits work for a milestone.
  - Body:
    - `milestone_id`
    - `github_repo_link`
  - Flow:
    1. Submission persisted with `IN_REVIEW` state.
    2. GitHub repo tree fetched, required deliverables checked.
    3. A summary is evaluated by the LLM (if configured).
    4. An `AIQAResult` is computed:
       - `score` (0–100)
       - `status` (`"completed" | "partial" | "failed"`)
       - `feedback`
    5. Escrow payout logic runs:
       - `score >= 85` → full milestone payment.
       - `60–84` → proportional payment.
       - `<60` → refund to employer.
    6. Freelancer’s PFI score is updated.

---

## Automated Escrow & Payout Workflow

1. **Employer creates project**  
   - `/projects` endpoint stores project and calls the AI milestone generator.

2. **AI generates milestones**  
   - LLM breaks the project into structured milestones with deliverables, deadlines, and payment percentages (summing to 100%).

3. **Employer funds escrow**  
   - `/escrow/deposit/{project_id}` moves the full budget from the employer wallet into an `EscrowAccount`.

4. **Freelancer delivers milestone**  
   - Submits GitHub repo and files through `/submissions`.

5. **AI Quality Assurance (AQA)**  
   - GitHub API fetches the repository tree.
   - Required deliverables are checked for presence.
   - A summary is passed to an LLM for objective scoring and feedback.

6. **Automated payout**  
   - Score‑based logic:
     - `score >= 85` → milestone `COMPLETED`, full milestone payout released.
     - `60–84` → `PARTIAL`, proportional payout, remainder refunded.
     - `<60` → `FAILED`, full refund for that milestone portion.

7. **PFI update & risk prediction**  
   - Freelancer’s Professional Fidelity Index (PFI) moves toward or away from 850 based on:
     - Milestone completion rate
     - Average quality score
     - Deadline adherence
     - Employer rating (placeholder weighting)
   - Risk prediction API (via `pfi_service.predict_milestone_risk`) combines PFI and project complexity into a `risk_score` 0–100.

---

## How TrustFlow AI Removes Trust Friction

- **Objective milestone definitions** – AI-generated milestones and deliverables provide a shared, structured contract between employer and freelancer.
- **Automatic escrow enforcement** – Funds are locked upfront and can only move through deterministic payout rules.
- **AI‑driven quality checks** – Submissions are validated via GitHub analysis and LLM evaluation, reducing subjective disputes.
- **Transparent reputation (PFI)** – Freelancers are scored between 300–850 using clear factors, improving selection and pricing decisions.
- **Risk prediction** – Employers can see the probability of milestone failure based on both project complexity and freelancer history.

Together, these components create a closed‑loop system where:

- Employers gain confidence that they only pay for verifiably delivered value.
- Freelancers gain confidence that approved work automatically unlocks payouts.
- Both parties can reason about reliability via a transparent PFI score.

---

## Development Notes

- Backend entrypoint: `backend/main.py`
- Database models: `backend/models.py`
- Pydantic schemas: `backend/schemas.py`
- Auth utilities (JWT, password hashing): `backend/auth.py`
- Routers:
  - `backend/routes/users.py`
  - `backend/routes/projects.py`
  - `backend/routes/milestones.py`
  - `backend/routes/escrow.py`
  - `backend/routes/submissions.py`
- Services:
  - `backend/services/project_service.py`
  - `backend/services/escrow_service.py`
  - `backend/services/pfi_service.py`
- AI helpers:
  - `backend/ai/milestone_generator.py`
  - `backend/ai/quality_assurance.py`
  - Top-level wrappers under `ai-agent/`

You can extend this foundation with:

- Real payment provider integrations for funding wallets.
- Richer front‑end flows for KYC, dispute resolution, and messaging.
- More sophisticated PFI inputs (on‑chain history, third‑party verifications, etc.).

