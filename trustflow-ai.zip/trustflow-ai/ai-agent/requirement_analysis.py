"""
Top-level AI agent module mirroring backend.ai.milestone_generator.
This keeps the requested repository structure while delegating to the backend package.
"""

from backend.ai.milestone_generator import generate_milestones_from_description

__all__ = ["generate_milestones_from_description"]

