"""
Compatibility wrapper exposing milestone generation from the backend AI package.
"""

from backend.ai.milestone_generator import generate_milestones_from_description

__all__ = ["generate_milestones_from_description"]

