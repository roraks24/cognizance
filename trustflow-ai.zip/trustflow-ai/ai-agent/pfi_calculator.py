"""
Compatibility wrapper for PFI and risk scoring utilities.
"""

from backend.services.pfi_service import predict_milestone_risk

__all__ = ["predict_milestone_risk"]

