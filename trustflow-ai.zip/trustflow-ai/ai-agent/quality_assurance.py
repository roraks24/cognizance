"""
Compatibility wrapper exposing quality assurance analysis from the backend AI package.
"""

from backend.ai.quality_assurance import analyze_submission_repo

__all__ = ["analyze_submission_repo"]

