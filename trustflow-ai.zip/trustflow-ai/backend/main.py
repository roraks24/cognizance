from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import users, projects, milestones, escrow, submissions


app = FastAPI(title="TrustFlow AI", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health_check():
    return {"status": "ok"}


app.include_router(users.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(milestones.router, prefix="/api")
app.include_router(escrow.router, prefix="/api")
app.include_router(submissions.router, prefix="/api")

