from sqlalchemy.orm import Session

from .. import models
from ..schemas import AIQAResult, RiskPrediction


def update_pfi_scores(db: Session, freelancer: models.User, qa_result: AIQAResult) -> None:
    completion_rate = 0.8 if qa_result.status == "completed" else 0.5 if qa_result.status == "partial" else 0.2
    avg_quality = qa_result.score / 100.0
    deadline_adherence = 0.8
    employer_rating = 0.8

    base_pfi = (
        0.4 * completion_rate
        + 0.3 * avg_quality
        + 0.2 * deadline_adherence
        + 0.1 * employer_rating
    )

    new_pfi = 300 + base_pfi * 550
    freelancer.pfi_score = max(300.0, min(850.0, new_pfi))
    db.commit()


def predict_milestone_risk(
    freelancer: models.User, project_complexity: float
) -> RiskPrediction:
    normalized_pfi = (freelancer.pfi_score - 300) / 550
    pfi_risk_component = 1.0 - normalized_pfi
    complexity_component = project_complexity

    raw_risk = 0.6 * complexity_component + 0.4 * pfi_risk_component
    risk_score = max(0.0, min(100.0, raw_risk * 100))
    return RiskPrediction(risk_score=risk_score)

