from sqlalchemy.orm import Session
from datetime import datetime
from typing import List

from .. import models, schemas
from ..ai.milestone_generator import generate_milestones_from_description
from ..ai.quality_assurance import analyze_submission_repo


def create_project_with_ai_milestones(
    db: Session, employer: models.User, project_in: schemas.ProjectCreate
) -> models.Project:
    project = models.Project(
        employer_id=employer.id,
        title=project_in.title,
        description=project_in.description,
        budget=project_in.budget,
        deadline=project_in.deadline or datetime.utcnow(),
    )
    db.add(project)
    db.commit()
    db.refresh(project)

    milestone_specs = generate_milestones_from_description(project_in.description, project_in.budget)

    for spec in milestone_specs:
        deliverables_str = "||".join(spec["deliverables"])
        milestone = models.Milestone(
            project_id=project.id,
            title=spec["title"],
            deliverables=deliverables_str,
            deadline_days=spec["deadline_days"],
            payment_percentage=spec["payment_percentage"],
        )
        db.add(milestone)

    db.commit()
    return project


def evaluate_submission_with_ai(
    db: Session, submission: models.Submission, milestone: models.Milestone
):
    qa_result = analyze_submission_repo(
        repo_url=submission.github_repo_link,
        required_files=milestone.deliverables.split("||"),
    )

    submission.score = qa_result.score
    submission.status = models.MilestoneStatus(qa_result.status)
    submission.feedback = qa_result.feedback
    db.commit()

    return qa_result

