from sqlalchemy.orm import Session
from fastapi import HTTPException

from .. import models
from ..schemas import AIQAResult


def employer_deposit_to_escrow(
    db: Session, employer: models.User, project_id: int
) -> models.EscrowAccount | None:
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project or project.employer_id != employer.id:
        raise HTTPException(status_code=404, detail="Project not found")

    if project.escrow_account:
        return project.escrow_account

    wallet = employer.wallet
    if wallet.balance < project.budget:
        raise HTTPException(status_code=400, detail="Insufficient employer wallet balance")

    wallet.balance -= project.budget

    escrow = models.EscrowAccount(
        project_id=project.id,
        total_amount=project.budget,
        released_amount=0.0,
    )
    db.add(escrow)

    tx = models.Transaction(
        sender_id=wallet.id,
        receiver_id=None,
        amount=project.budget,
        type=models.TransactionType.ESCROW_FUND,
    )
    db.add(tx)

    db.commit()
    db.refresh(escrow)
    return escrow


def process_milestone_payout(
    db: Session, milestone: models.Milestone, qa_result: AIQAResult
) -> None:
    project = milestone.project
    escrow = project.escrow_account
    if not escrow:
        raise HTTPException(status_code=400, detail="Escrow not funded")

    employer_wallet = project.employer.wallet
    freelancer_wallet = milestone.freelancer.wallet if milestone.freelancer else None

    if not freelancer_wallet:
        raise HTTPException(status_code=400, detail="Freelancer wallet not found")

    milestone_amount = (milestone.payment_percentage / 100.0) * project.budget

    payout_amount = 0.0
    refund_amount = 0.0

    if qa_result.score >= 85:
        payout_amount = milestone_amount
        milestone.status = models.MilestoneStatus.COMPLETED
    elif 60 <= qa_result.score < 85:
        ratio = qa_result.score / 100.0
        payout_amount = milestone_amount * ratio
        refund_amount = milestone_amount - payout_amount
        milestone.status = models.MilestoneStatus.PARTIAL
    else:
        refund_amount = milestone_amount
        milestone.status = models.MilestoneStatus.FAILED

    if payout_amount > 0:
        escrow.released_amount += payout_amount
        freelancer_wallet.balance += payout_amount
        db.add(
            models.Transaction(
                sender_id=None,
                receiver_id=freelancer_wallet.id,
                amount=payout_amount,
                type=models.TransactionType.PAYOUT,
            )
        )

    if refund_amount > 0:
        employer_wallet.balance += refund_amount
        escrow.released_amount += 0
        db.add(
            models.Transaction(
                sender_id=None,
                receiver_id=employer_wallet.id,
                amount=refund_amount,
                type=models.TransactionType.REFUND,
            )
        )

    db.commit()

