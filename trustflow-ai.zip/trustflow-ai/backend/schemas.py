from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field

from .models import UserRole, MilestoneStatus


class UserBase(BaseModel):
    name: str
    email: EmailStr
    role: UserRole


class UserCreate(UserBase):
    password: str = Field(min_length=6)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(UserBase):
    id: int
    pfi_score: float

    class Config:
        orm_mode = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class ProjectBase(BaseModel):
    title: str
    description: str
    budget: float
    deadline: Optional[datetime]


class ProjectCreate(ProjectBase):
    pass


class ProjectOut(ProjectBase):
    id: int
    employer_id: int

    class Config:
        orm_mode = True


class MilestoneBase(BaseModel):
    title: str
    deliverables: List[str]
    deadline_days: int
    payment_percentage: float


class MilestoneCreate(MilestoneBase):
    pass


class MilestoneOut(MilestoneBase):
    id: int
    project_id: int
    freelancer_id: Optional[int]
    status: MilestoneStatus

    class Config:
        orm_mode = True


class EscrowAccountOut(BaseModel):
    id: int
    project_id: int
    total_amount: float
    released_amount: float
    status: str

    class Config:
        orm_mode = True


class SubmissionCreate(BaseModel):
    milestone_id: int
    github_repo_link: str


class SubmissionOut(BaseModel):
    id: int
    milestone_id: int
    freelancer_id: int
    github_repo_link: str
    files_summary: Optional[str]
    score: Optional[float]
    status: MilestoneStatus
    feedback: Optional[str]

    class Config:
        orm_mode = True


class AIQAResult(BaseModel):
    score: float
    status: str
    feedback: str


class RiskPrediction(BaseModel):
    risk_score: float

