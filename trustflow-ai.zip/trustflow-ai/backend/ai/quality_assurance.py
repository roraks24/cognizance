from typing import List
import os
import requests
import openai

from ..schemas import AIQAResult


openai.api_key = os.getenv("OPENAI_API_KEY", "")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")


def _fetch_repo_tree(repo_url: str) -> List[str]:
    """
    Fetch a flat list of file paths from a GitHub repository using the GitHub API.
    """
    try:
        if "github.com" not in repo_url:
            return []
        parts = repo_url.rstrip("/").split("/")
        owner, repo = parts[-2], parts[-1]
        api_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/HEAD?recursive=1"
        headers = {}
        if GITHUB_TOKEN:
            headers["Authorization"] = f"token {GITHUB_TOKEN}"
        resp = requests.get(api_url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        return [item["path"] for item in data.get("tree", []) if item.get("type") == "blob"]
    except Exception:
        return []


def analyze_submission_repo(repo_url: str, required_files: List[str]) -> AIQAResult:
    """
    Analyze a submission repository:
    - fetch repo tree via GitHub API
    - check presence of required deliverable-related files
    - send a summary to an LLM for a quality score and feedback
    """
    files = _fetch_repo_tree(repo_url)
    files_lower = [f.lower() for f in files]

    coverage = 0
    for req in required_files:
        req_l = req.lower()
        if any(req_l in f for f in files_lower):
            coverage += 1

    coverage_ratio = coverage / max(1, len(required_files))

    base_score = 60 + coverage_ratio * 40
    base_score = min(100, max(0, base_score))

    feedback = f"Found {coverage} of {len(required_files)} expected deliverables in the repository."

    status: str
    if base_score >= 85:
        status = "completed"
    elif base_score >= 60:
        status = "partial"
    else:
        status = "failed"

    # Optionally refine with LLM if key is available
    if openai.api_key:
        try:
            summary = "\n".join(files[:100])
            prompt = (
                "You are a senior code reviewer.\n"
                f"Deliverables: {required_files}\n"
                f"Repository file list (truncated):\n{summary}\n"
                "Rate how well the repo satisfies the deliverables (0-100) "
                "and give 2-3 sentences of feedback. Respond as JSON with "
                '{"score": <number>, "feedback": "<text>"}'
            )
            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a strict software quality reviewer."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
            )
            import json

            content = response.choices[0].message["content"]
            data = json.loads(content)
            score = float(data.get("score", base_score))
            feedback = data.get("feedback", feedback)
            base_score = min(100, max(0, score))
            if base_score >= 85:
                status = "completed"
            elif base_score >= 60:
                status = "partial"
            else:
                status = "failed"
        except Exception:
            pass

    return AIQAResult(score=base_score, status=status, feedback=feedback)

