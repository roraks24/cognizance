"""
AI helper package for TrustFlow AI backend.

This layer wraps interactions with LLMs and external analysis (e.g., GitHub)
so the rest of the application can call simple Python functions.
"""

