from typing import List, Dict
import os

import openai


openai.api_key = os.getenv("OPENAI_API_KEY", "")


SYSTEM_PROMPT = """
You are an expert project planner for software and digital projects.
Given a project description and total budget, break it into 3-6 milestones.
Each milestone should have:
- title
- deliverables (short bullet-like strings)
- deadline_days (relative days from project start)
- payment_percentage (sum of all milestones should be 100).
Return ONLY valid JSON list.
"""


def generate_milestones_from_description(description: str, budget: float) -> List[Dict]:
    """
    Use an LLM to generate milestone specifications from a free-form description.
    Falls back to a simple heuristic plan if the LLM is unavailable.
    """
    if not openai.api_key:
        return _fallback_milestones(description, budget)

    user_prompt = f"Project description: {description}\nTotal budget: {budget}"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.3,
        )
        content = response.choices[0].message["content"]
        import json

        milestones = json.loads(content)
        return milestones
    except Exception:
        return _fallback_milestones(description, budget)


def _fallback_milestones(description: str, budget: float) -> List[Dict]:
    return [
        {
            "title": "Planning & Requirements",
            "deliverables": ["requirements_spec", "project_plan"],
            "deadline_days": 3,
            "payment_percentage": 20,
        },
        {
            "title": "Implementation",
            "deliverables": ["core_features", "tests"],
            "deadline_days": 10,
            "payment_percentage": 50,
        },
        {
            "title": "Polish & Delivery",
            "deliverables": ["bug_fixes", "documentation"],
            "deadline_days": 5,
            "payment_percentage": 30,
        },
    ]

