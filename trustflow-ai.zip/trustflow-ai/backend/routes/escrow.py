from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_role
from ..database import get_db
from ..services.escrow_service import employer_deposit_to_escrow


router = APIRouter(prefix="/escrow", tags=["escrow"])


@router.post("/deposit/{project_id}", response_model=schemas.EscrowAccountOut)
def deposit_to_escrow(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_role(current_user, models.UserRole.EMPLOYER)
    escrow = employer_deposit_to_escrow(db=db, employer=current_user, project_id=project_id)
    if not escrow:
        raise HTTPException(status_code=400, detail="Unable to create escrow")
    return escrow


@router.get("/{project_id}", response_model=schemas.EscrowAccountOut)
def get_escrow(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    escrow = (
        db.query(models.EscrowAccount)
        .join(models.Project)
        .filter(models.Project.id == project_id)
        .first()
    )
    if not escrow:
        raise HTTPException(status_code=404, detail="Escrow not found")
    return escrow

