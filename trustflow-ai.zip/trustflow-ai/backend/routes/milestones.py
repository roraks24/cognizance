from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import get_db


router = APIRouter(prefix="/milestones", tags=["milestones"])


@router.get("/{project_id}", response_model=list[schemas.MilestoneOut])
def list_project_milestones(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    milestones = db.query(models.Milestone).filter(models.Milestone.project_id == project_id).all()
    return [
        schemas.MilestoneOut(
            id=m.id,
            project_id=m.project_id,
            freelancer_id=m.freelancer_id,
            title=m.title,
            deliverables=m.deliverables.split("||"),
            deadline_days=m.deadline_days,
            payment_percentage=m.payment_percentage,
            status=m.status,
        )
        for m in milestones
    ]

