from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_role
from ..database import get_db
from ..services.escrow_service import process_milestone_payout
from ..services.pfi_service import update_pfi_scores
from ..services.project_service import evaluate_submission_with_ai


router = APIRouter(prefix="/submissions", tags=["submissions"])


@router.post("", response_model=schemas.SubmissionOut)
def submit_milestone(
    submission_in: schemas.SubmissionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_role(current_user, models.UserRole.FREELANCER)
    milestone = (
        db.query(models.Milestone)
        .filter(models.Milestone.id == submission_in.milestone_id)
        .first()
    )
    if not milestone:
        raise HTTPException(status_code=404, detail="Milestone not found")

    submission = models.Submission(
        milestone_id=milestone.id,
        freelancer_id=current_user.id,
        github_repo_link=submission_in.github_repo_link,
    )
    db.add(submission)
    milestone.status = models.MilestoneStatus.IN_REVIEW
    db.commit()
    db.refresh(submission)

    qa_result = evaluate_submission_with_ai(db=db, submission=submission, milestone=milestone)

    process_milestone_payout(db=db, milestone=milestone, qa_result=qa_result)

    update_pfi_scores(db=db, freelancer=current_user, qa_result=qa_result)

    db.refresh(submission)
    return submission

