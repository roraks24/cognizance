from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_role
from ..database import get_db
from ..services.project_service import create_project_with_ai_milestones


router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=schemas.ProjectOut)
def create_project(
    project_in: schemas.ProjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_role(current_user, models.UserRole.EMPLOYER)
    project = create_project_with_ai_milestones(db=db, employer=current_user, project_in=project_in)
    return project


@router.get("", response_model=list[schemas.ProjectOut])
def list_projects(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if current_user.role == models.UserRole.EMPLOYER:
        projects = db.query(models.Project).filter(models.Project.employer_id == current_user.id).all()
    else:
        projects = (
            db.query(models.Project)
            .join(models.Milestone)
            .filter(models.Milestone.freelancer_id == current_user.id)
            .all()
        )
    return projects

