from datetime import datetime
from enum import Enum

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    DateTime,
    Boolean,
    ForeignKey,
    Text,
    Enum as SqlEnum,
)
from sqlalchemy.orm import relationship

from .database import Base


class UserRole(str, Enum):
    EMPLOYER = "employer"
    FREELANCER = "freelancer"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(SqlEnum(UserRole), nullable=False)
    pfi_score = Column(Float, default=500.0)

    projects = relationship("Project", back_populates="employer")
    milestones = relationship("Milestone", back_populates="freelancer")
    wallet = relationship("Wallet", back_populates="user", uselist=False)


class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    employer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    budget = Column(Float, nullable=False)
    deadline = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    employer = relationship("User", back_populates="projects")
    milestones = relationship("Milestone", back_populates="project")
    escrow_account = relationship("EscrowAccount", back_populates="project", uselist=False)


class MilestoneStatus(str, Enum):
    PENDING = "pending"
    IN_REVIEW = "in_review"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"


class Milestone(Base):
    __tablename__ = "milestones"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    freelancer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    title = Column(String(255), nullable=False)
    deliverables = Column(Text, nullable=False)
    deadline_days = Column(Integer, nullable=False)
    payment_percentage = Column(Float, nullable=False)
    status = Column(SqlEnum(MilestoneStatus), default=MilestoneStatus.PENDING)

    project = relationship("Project", back_populates="milestones")
    freelancer = relationship("User", back_populates="milestones")
    submissions = relationship("Submission", back_populates="milestone")


class Wallet(Base):
    __tablename__ = "wallets"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True)
    balance = Column(Float, default=0.0)

    user = relationship("User", back_populates="wallet")
    outgoing_transactions = relationship(
        "Transaction", back_populates="sender", foreign_keys="Transaction.sender_id"
    )
    incoming_transactions = relationship(
        "Transaction", back_populates="receiver", foreign_keys="Transaction.receiver_id"
    )


class TransactionType(str, Enum):
    DEPOSIT = "deposit"
    ESCROW_FUND = "escrow_fund"
    PAYOUT = "payout"
    REFUND = "refund"


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey("wallets.id"), nullable=True)
    receiver_id = Column(Integer, ForeignKey("wallets.id"), nullable=True)
    amount = Column(Float, nullable=False)
    type = Column(SqlEnum(TransactionType), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    sender = relationship("Wallet", foreign_keys=[sender_id], back_populates="outgoing_transactions")
    receiver = relationship("Wallet", foreign_keys=[receiver_id], back_populates="incoming_transactions")


class EscrowStatus(str, Enum):
    OPEN = "open"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class EscrowAccount(Base):
    __tablename__ = "escrow_accounts"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), unique=True, nullable=False)
    total_amount = Column(Float, nullable=False)
    released_amount = Column(Float, default=0.0)
    status = Column(SqlEnum(EscrowStatus), default=EscrowStatus.OPEN)

    project = relationship("Project", back_populates="escrow_account")


class Submission(Base):
    __tablename__ = "submissions"

    id = Column(Integer, primary_key=True, index=True)
    milestone_id = Column(Integer, ForeignKey("milestones.id"), nullable=False)
    freelancer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    github_repo_link = Column(String(512), nullable=False)
    files_summary = Column(Text, nullable=True)
    score = Column(Float, nullable=True)
    status = Column(SqlEnum(MilestoneStatus), default=MilestoneStatus.IN_REVIEW)
    feedback = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    milestone = relationship("Milestone", back_populates="submissions")

